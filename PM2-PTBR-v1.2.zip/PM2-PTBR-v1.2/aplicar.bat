@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0aplicar.ps1" %*
echo.
pause
