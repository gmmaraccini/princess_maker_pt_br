param([string]$Jogo)
$ErrorActionPreference = 'Stop'

Write-Host '=================================================='
Write-Host '  PRINCESS MAKER 2 - TRADUCAO PT-BR - Versao 1.2'
Write-Host '  Traduzido para Portugues-BR por Gabriel Maraccini'
Write-Host '=================================================='
Write-Host ''

$codigo = @'
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

public static class Pm2Patch
{
    static readonly byte[] Key = { 0x13, 0xA2, 0xB4, 0x6C, 0x79, 0x4C };

    static byte[] Decode(byte[] b)
    {
        if (b.Length < 2 || b[0] != 1 || b[1] != 4) throw new Exception("Script em formato inesperado.");
        byte[] s = new byte[b.Length - 2];
        for (int i = 0; i < s.Length; i++) s[i] = (byte)(b[i + 2] - Key[i % 6]);
        List<byte> o = new List<byte>();
        int p = 0;
        while (true)
        {
            int c = BitConverter.ToUInt16(s, p);
            p += 2;
            if (c == 0) break;
            if ((c & 0x8000) != 0)
            {
                int n = (c & 0x7fff) * 2;
                int back = BitConverter.ToUInt16(s, p);
                p += 2;
                for (int i = 0; i < n; i++) o.Add(o[o.Count - back]);
            }
            else
            {
                for (int i = 0; i < c * 2; i++) o.Add(s[p + i]);
                p += c * 2;
            }
        }
        return o.ToArray();
    }

    static void Word(List<byte> o, int v)
    {
        o.Add((byte)v);
        o.Add((byte)(v >> 8));
    }

    static void Flush(List<byte> o, List<byte> lit)
    {
        for (int i = 0; i < lit.Count; i += 352)
        {
            int n = Math.Min(352, lit.Count - i);
            Word(o, n / 2);
            o.AddRange(lit.GetRange(i, n));
        }
        lit.Clear();
    }

    static void Index(Dictionary<uint, List<int>> heads, byte[] t, int i)
    {
        if (i + 4 > t.Length) return;
        uint k = BitConverter.ToUInt32(t, i);
        List<int> l;
        if (!heads.TryGetValue(k, out l))
        {
            l = new List<int>();
            heads[k] = l;
        }
        l.Add(i);
    }

    static byte[] Compress(byte[] t)
    {
        if ((t.Length & 1) != 0)
        {
            Array.Resize(ref t, t.Length + 1);
            t[t.Length - 1] = 12;
        }
        int n = t.Length;
        List<byte> o = new List<byte>();
        List<byte> lit = new List<byte>();
        Dictionary<uint, List<int>> heads = new Dictionary<uint, List<int>>();
        int p = 0;
        while (p < n)
        {
            int best = 0, back = 0;
            List<int> c;
            if (p + 4 <= n && heads.TryGetValue(BitConverter.ToUInt32(t, p), out c))
            {
                for (int j = c.Count - 1; j >= 0 && j >= c.Count - 64; j--)
                {
                    int q = c[j];
                    if (p - q > 28000) break;
                    if (p - q < 2) continue;
                    int l = 0;
                    while (l < 1024 && p + l < n && t[q + l] == t[p + l]) l++;
                    l &= ~1;
                    if (l > best)
                    {
                        best = l;
                        back = p - q;
                    }
                }
            }
            if (best >= 8)
            {
                Flush(o, lit);
                Word(o, 0x8000 | (best / 2));
                Word(o, back);
                for (int i = p; i < p + best; i++) Index(heads, t, i);
                p += best;
            }
            else
            {
                lit.Add(t[p]);
                lit.Add(t[p + 1]);
                Index(heads, t, p);
                Index(heads, t, p + 1);
                p += 2;
            }
        }
        Flush(o, lit);
        Word(o, 0);
        byte[] r = new byte[o.Count + 2];
        r[0] = 1;
        r[1] = 4;
        for (int i = 0; i < o.Count; i++) r[i + 2] = (byte)(o[i] + Key[i % 6]);
        return r;
    }

    static byte[] Ops(byte[] src, BinaryReader r)
    {
        MemoryStream m = new MemoryStream();
        while (true)
        {
            int kind = r.ReadByte();
            if (kind == 0) break;
            if (kind == 1)
            {
                int off = (int)r.ReadUInt32();
                int len = (int)r.ReadUInt32();
                m.Write(src, off, len);
            }
            else
            {
                byte[] d = r.ReadBytes((int)r.ReadUInt32());
                m.Write(d, 0, d.Length);
            }
        }
        return m.ToArray();
    }

    static byte[] Lbx(byte[] d, BinaryReader r)
    {
        int count = BitConverter.ToUInt16(d, d.Length - 6);
        int toc = (int)BitConverter.ToUInt32(d, d.Length - 4);
        byte[][] data = new byte[count][];
        for (int i = 0; i < count; i++)
        {
            int e = toc + i * 20;
            int off = (int)BitConverter.ToUInt32(d, e + 12);
            int size = (int)BitConverter.ToUInt32(d, e + 16);
            data[i] = new byte[size];
            Array.Copy(d, off, data[i], 0, size);
        }
        int changed = r.ReadUInt16();
        for (int i = 0; i < changed; i++)
        {
            int index = r.ReadUInt16();
            data[index] = Compress(Ops(Decode(data[index]), r));
        }
        MemoryStream body = new MemoryStream();
        MemoryStream table = new MemoryStream();
        BinaryWriter tw = new BinaryWriter(table);
        for (int i = 0; i < count; i++)
        {
            tw.Write(d, toc + i * 20, 12);
            tw.Write((uint)body.Length);
            tw.Write((uint)data[i].Length);
            body.Write(data[i], 0, data[i].Length);
        }
        uint start = (uint)body.Length;
        byte[] t = table.ToArray();
        body.Write(t, 0, t.Length);
        BinaryWriter bw = new BinaryWriter(body);
        bw.Write((ushort)count);
        bw.Write(start);
        return body.ToArray();
    }

    static bool Same(byte[] data, byte[] hash)
    {
        byte[] h = SHA256.Create().ComputeHash(data);
        for (int i = 0; i < h.Length; i++) if (h[i] != hash[i]) return false;
        return true;
    }

    public static Dictionary<string, byte[]> Build(string dir, string patch)
    {
        Dictionary<string, byte[]> result = new Dictionary<string, byte[]>();
        using (BinaryReader r = new BinaryReader(File.OpenRead(patch)))
        {
            if (Encoding.ASCII.GetString(r.ReadBytes(6)) != "PM2BR1") throw new Exception("Arquivo traducao.dat invalido.");
            int files = r.ReadUInt16();
            for (int i = 0; i < files; i++)
            {
                string name = Encoding.ASCII.GetString(r.ReadBytes(r.ReadByte()));
                byte[] before = r.ReadBytes(32);
                byte[] after = r.ReadBytes(32);
                string path = Path.Combine(dir, name);
                if (!File.Exists(path)) throw new Exception("Arquivo nao encontrado: " + name);
                byte[] d = File.ReadAllBytes(path);
                if (!Same(d, before)) throw new Exception(name + " e diferente do esperado. Use a versao DOS em ingles, sem modificacoes.");
                byte[] n = r.ReadByte() == 0 ? Ops(d, r) : Lbx(d, r);
                if (!Same(n, after)) throw new Exception("Falha ao gerar " + name + ".");
                result[name] = n;
            }
        }
        return result;
    }
}
'@

try {
    if (Get-Process -Name DOSBox -ErrorAction SilentlyContinue) { throw 'Feche o DOSBox e rode o aplicar.bat de novo.' }

    if (-not $Jogo) {
        $pai = Split-Path -Parent $PSScriptRoot
        foreach ($c in @($pai, (Join-Path $pai 'Princess2'))) {
            if (Test-Path -LiteralPath (Join-Path $c 'PM2.EXE')) { $Jogo = $c; break }
        }
    }
    if (-not $Jogo) { $Jogo = (Read-Host 'Cole o caminho da pasta do jogo (onde esta o PM2.EXE)').Trim().Trim('"') }
    if (-not $Jogo -or -not (Test-Path -LiteralPath (Join-Path $Jogo 'PM2.EXE'))) { throw 'PM2.EXE nao encontrado.' }

    $Jogo = (Get-Item -LiteralPath $Jogo).FullName.TrimEnd('\')
    if ($Jogo.EndsWith('-BR')) { throw 'Escolha a pasta original do jogo, nao a pasta -BR.' }
    $destino = $Jogo + '-BR'

    Write-Host "Jogo original: $Jogo"
    Write-Host 'Gerando os arquivos traduzidos...'
    Add-Type -TypeDefinition $codigo -Language CSharp
    $arquivos = [Pm2Patch]::Build($Jogo, (Join-Path $PSScriptRoot 'traducao.dat'))

    if (-not (Test-Path -LiteralPath (Join-Path $destino 'PM2.EXE'))) {
        Write-Host "Criando a pasta $destino ..."
        New-Item -ItemType Directory -Force -Path $destino | Out-Null
        Get-ChildItem -LiteralPath $Jogo -Force | Copy-Item -Destination $destino -Recurse -Force
    }
    foreach ($nome in $arquivos.Keys) {
        [IO.File]::WriteAllBytes((Join-Path $destino $nome), $arquivos[$nome])
    }

    $raiz = Split-Path -Parent $Jogo
    $pasta = Split-Path -Leaf $destino
    Write-Host ''
    if (Test-Path -LiteralPath (Join-Path $raiz 'DOSBOX\DOSBox.exe')) {
        $conf = @('[sdl]', 'fullscreen=false', 'output=surface', '[autoexec]', '@echo off', "mount C "".\$pasta""", 'c:', 'PM2.EXE')
        Set-Content -LiteralPath (Join-Path $raiz 'DOSBOX\dosbox_br.conf') -Value $conf -Encoding Default
        $bat = @(
            '@echo off',
            'title Princess Maker 2 - PT-BR',
            'cd /d "%~dp0"',
            'echo.',
            'echo   PRINCESS MAKER 2 - PORTUGUES-BR',
            'echo   Traduzido por Gabriel Maraccini',
            'echo.',
            'set "BASE="',
            'if exist ".\DOSBOX\dosbox.conf" set BASE=-conf ".\DOSBOX\dosbox.conf"',
            'start "" ".\DOSBOX\DOSBox.exe" %BASE% -conf ".\DOSBOX\dosbox_br.conf" -noconsole',
            'timeout /t 4 >nul'
        )
        Set-Content -LiteralPath (Join-Path $raiz 'PrincessMaker2-BR.bat') -Value $bat -Encoding ASCII
        Write-Host "Pronto. Abra o jogo por $raiz\PrincessMaker2-BR.bat"
    } else {
        Write-Host 'Pronto. No seu DOSBox, digite:'
        Write-Host "  mount c ""$destino"""
        Write-Host '  c:'
        Write-Host '  PM2.EXE'
    }
    exit 0
} catch {
    $erro = $_.Exception
    while ($erro.InnerException) { $erro = $erro.InnerException }
    Write-Host ''
    Write-Host "ERRO: $($erro.Message)"
    exit 1
}
